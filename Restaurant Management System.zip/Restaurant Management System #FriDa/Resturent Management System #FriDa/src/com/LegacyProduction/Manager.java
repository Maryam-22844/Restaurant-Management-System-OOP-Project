package com.LegacyProduction;

public class Manager extends Servant{
    //Constructor

    public Manager() {
        super();
    }

    public Manager(String username, String email, String password) {
        super(username, email, password);
    }

    public Manager(String name, String username, String email, String password) {
        super(name, username, email, password);
    }

    public Manager(String name, String address, String username, String email, String password) {
        super(name, address, username, email, password);
    }

    public Manager(String name, String phoneNumber, String address, String username, String email, String password) {
        super(name, phoneNumber, address, username, email, password);
    }
}
