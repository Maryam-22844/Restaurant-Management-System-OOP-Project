package com.LegacyProduction;

public class Customer extends Person{

    private int customerID=110, balance, totalBill;
    //Constructor
    public Customer(){
       super();
    }

    public Customer(String name) {
        super(name);
    }

    public Customer(String name, String address) {
        super(name, address);
    }

    public Customer(String name, String phoneNumber, String address) {
        super(name, phoneNumber, address);
    }

    public Customer(String name, String phoneNumber, String address, int balance) {
        super(name, phoneNumber, address);
        this.balance= balance;
    }

    //Setter Function


    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public void setTotalBill(int totalBill) {
        this.totalBill = totalBill;
    }

    //Getter Function

    public int getTotalBill() {
        return totalBill;
    }

    public int getCustomerID() {
        return customerID;
    }

    public int getBalance() {
        return balance;
    }


    //calculate

    public int solve(){
        return this.balance-this.getTotalBill();
    }
}
