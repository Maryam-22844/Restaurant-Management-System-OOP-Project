package com.LegacyProduction;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.SimpleFormatter;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
            GraphicalInterface testing = new GraphicalInterface();
            testing.homePage();

//        System.out.println();
//        File file = new File("files\\FastFood.csv");
//        try(FileReader fileReader = new FileReader(file);){
//            BufferedReader bufferedReader = new BufferedReader(fileReader);
//            String line;
//            while((line=bufferedReader.readLine())!=null){
//                System.out.println(line);
//            }
//        }catch (IOException e){
//            System.out.println(e.getMessage());
//        }


    }
}
