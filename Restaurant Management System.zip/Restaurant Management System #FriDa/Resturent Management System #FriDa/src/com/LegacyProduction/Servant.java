package com.LegacyProduction;

public class Servant extends Person{
    private String username, email, password;
    private Boolean isManager;

    //Constructor

    public Servant(){
        super();
        this.email=this.password=this.username=null;
    }

    public Servant(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public Servant(String name, String username, String email, String password) {
        super(name);
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public Servant(String name, String address, String username, String email, String password) {
        super(name, address);
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public Servant(String name, String phoneNumber, String address, String username, String email, String password) {
        super(name, phoneNumber, address);
        this.username = username;
        this.email = email;
        this.password = password;
    }

    //Getter Function


    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public Boolean getManager() {
        return isManager;
    }

    //Setter Function

    public void setManager(Boolean manager) {
        isManager = manager;
    }


    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
