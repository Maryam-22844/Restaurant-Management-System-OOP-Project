package com.LegacyProduction;

public class Meal extends Food{

    private String foodType="Meal";

    Meal(){
        super();
    }

    Meal(String foodType){
        super(foodType);
    }

    Meal(int id){
        super(id);
    }

    Meal(int id, String foodType){
        super(id, foodType);
    }

    Meal(int id, int nFood){
        super(id, nFood);
    }

    Meal(int id, int nFood, String foodType){
        super(id, nFood, foodType);
    }
}
