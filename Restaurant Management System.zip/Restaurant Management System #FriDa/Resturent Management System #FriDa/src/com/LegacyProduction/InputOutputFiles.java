package com.LegacyProduction;

import java.io.*;

public class InputOutputFiles {
    File file;

    public InputOutputFiles(){
        file = null;
    }

    public InputOutputFiles(File file){
        this.file=file;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }


    /*
    *
    *
    *
    *Functions
    *
    *
    *
    */


    public boolean search(File file, String x, String y){                   //Search Function
        boolean match=false;
        try(FileReader fileReader = new FileReader(file);){

            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while((line=bufferedReader.readLine())!=null){
                if(line.contains(x) && line.contains(y)){
                    match = (line.contains(x) && line.contains(y)) ? true: false;
                    break;
                }

            }


        }catch (IOException e){
            match=  false;
        }
        return match;
    }

    public boolean search(File file, String x){                   //Search Function
        boolean match=false;
        try(FileReader fileReader = new FileReader(file);){

            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while((line=bufferedReader.readLine())!=null){
                if(line.contains(x)){
                    match = line.contains(x);
                    break;
                }

            }
            return match;

        }catch (IOException e){
            match=  false;
        }
        return match;
    }

       public void write(File file, String x){

        //Write Function actually doing appened
        try(FileWriter fileWriter = new FileWriter(file, true)){
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.append(x);
            bufferedWriter.newLine();
            bufferedWriter.close();

        }catch(IOException e){
            try{
                file.createNewFile();
                GraphicalInterface obj = new GraphicalInterface();
                obj.alert("File for Data Writing Not Found");
                write(file,x);
            }catch (IOException f){
                GraphicalInterface obj = new GraphicalInterface();
                obj.alert("File Not Found");
            }
        }
    }

    public String[] findReturn(File file, String x){
        String line="";
        try(FileReader fileReader = new FileReader(file);){

            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while((line=bufferedReader.readLine())!=null){
                String[] data = line.split(",",2);
                try{
                    if(x.equals(data[0])){
                        return line.split(",");
                    }
                }catch (ArrayIndexOutOfBoundsException e){
                    return null;
                }

            }
        }catch (IOException e){
            return null;
        }
        return null;
    }

    public String readLine(File file){
        try(FileReader fileReader= new FileReader(file);){
            BufferedReader bufferedReader= new BufferedReader(fileReader);
            return bufferedReader.readLine();
        }catch (IOException e){
            GraphicalInterface a= new GraphicalInterface();
            a.alert("File Not Found For Food: Please Check files: ");
        }
        return null;
    }

    public int countLines(File file){

        try(FileReader fileReader= new FileReader(file);){
            int i=0;
            BufferedReader bufferedReader= new BufferedReader(fileReader);
            String line;

            while((line= bufferedReader.readLine())!=null){
                i++;
            }

            return i;

        }catch (IOException e){
            GraphicalInterface a= new GraphicalInterface();
            a.alert("File Not Found For Food: Please Check files: ");
        }
        return 0;
    }

    public String[] findReturn(File file, char x, int j){
        String line="";
        try(FileReader fileReader = new FileReader(file);){

            BufferedReader bufferedReader = new BufferedReader(fileReader);
            int i=0;
            while(i<=j){
                line=bufferedReader.readLine();
                if(i==j){
                    return line.split(String.valueOf(x));
                }
                i++;
            }
        }catch (IOException e){
            return null;
        }
        return null;
    }
}
