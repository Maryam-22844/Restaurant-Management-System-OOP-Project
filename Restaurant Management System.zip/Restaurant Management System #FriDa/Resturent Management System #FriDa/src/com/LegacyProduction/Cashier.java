package com.LegacyProduction;

public class Cashier extends Servant{
    //Constructor

    public Cashier(){
        super();
    }

    public Cashier(String username, String email, String password) {
        super(username, email, password);
    }

    public Cashier(String name, String username, String email, String password) {
        super(name, username, email, password);
    }

    public Cashier(String name, String address, String username, String email, String password) {
        super(name, address, username, email, password);
    }

    public Cashier(String name, String phoneNumber, String address, String username, String email, String password) {
        super(name, phoneNumber, address, username, email, password);
    }

}
