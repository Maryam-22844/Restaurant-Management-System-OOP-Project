package com.LegacyProduction;

import java.io.Writer;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Person {
    private String name, phoneNumber, address;
    private final Scanner  Write = new Scanner(System.in);


    //Constructors

    public Person(){
        phoneNumber=address=name= null;
    }

    public Person(String name) {
        this.name = name;
    }

    public Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public Person(String name, String phoneNumber, String address) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    //Setter Functions


    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        if( Pattern.matches(this.regexPhone(),phoneNumber)){
            this.phoneNumber = phoneNumber;
        }else{
            String newPhoneNumber = Write.next();
            setPhoneNumber(newPhoneNumber);
        }

    }

    public void setAddress(String address) {
        this.address = address;
    }

    //Getter Functions

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    //Other Functions

    public void changeName(String name){
        this.name= name;
    }

    public void changeAddress(String adrs){
        this.address= adrs;
    }

    public void changePhoneNumber(String number){
        this.phoneNumber = number;
    }

    //Regular Expression For Phone Number

    public String regexPhone(){
        return "03[0-9]{9}";
    }
}
