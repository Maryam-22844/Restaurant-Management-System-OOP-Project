package com.LegacyProduction;

public class ColdDrinks extends Food{

    private String foodType="Cold Drinks";

    ColdDrinks(){
        super();
    }

    ColdDrinks(String foodType){
        super(foodType);
    }

    ColdDrinks(int id){
        super(id);
    }

    ColdDrinks(int id, String foodType){
        super(id, foodType);
    }

    ColdDrinks(int id, int nFood){
        super(id, nFood);
    }

    ColdDrinks(int id, int nFood, String foodType){
        super(id, nFood, foodType);
    }
}
