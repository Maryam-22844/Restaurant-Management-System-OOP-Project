package com.LegacyProduction;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Food {
    private List<String> foodName;
    private List<Integer> foodID;
    private List<Integer> foodPrice;
    private int totalFoods;
    private int id;
    private String foodType="Food";

    //Constructors

    Food(){
        id=1;
        foodName=new ArrayList<String>();
        foodID= new ArrayList<Integer>();
        foodPrice= new ArrayList<Integer>();
        totalFoods=0;
    }

    Food(String foodType){
        id=1;
        foodName=new ArrayList<String>();
        foodID= new ArrayList<Integer>();
        foodPrice= new ArrayList<Integer>();
        totalFoods=0;
        this.foodType=foodType;
    }

    Food(int id){
        foodName=new ArrayList<String>();
        foodID= new ArrayList<Integer>();
        foodPrice= new ArrayList<Integer>();
        totalFoods=0;
        this.id= id;
    }

    Food(int id, String foodType){
        foodName=new ArrayList<String>();
        foodID= new ArrayList<Integer>();
        foodPrice= new ArrayList<Integer>();
        totalFoods=0;
        this.id= id;
        this.foodType=foodType;
    }

    Food(int id, int nFood){
        foodName=new ArrayList<String>();
        foodID= new ArrayList<Integer>();
        foodPrice= new ArrayList<Integer>();
        totalFoods=0;
        this.id= id;
        add(nFood);
    }

    Food(int id, int nFood, String foodType){
        foodName=new ArrayList<String>();
        foodID= new ArrayList<Integer>();
        foodPrice= new ArrayList<Integer>();
        totalFoods=0;
        this.id= id;
        add(nFood);
        this.foodType=foodType;
    }

    //constant

    private final Scanner WRITE = new Scanner(System.in);

    //Setter Functions


    public void setId(int id) {
        this.id = id;
    }

    public void setTotalFoods(int totalFoods) {
        this.totalFoods = totalFoods;
    }

    public void setFoodPrice(List<Integer> foodPrice) {
        this.foodPrice = foodPrice;
    }

    public void setFoodName(List<String> foodName) {
        this.foodName = foodName;
    }

    public void setFoodID(List<Integer> foodID) {
        this.foodID = foodID;
    }

    //Getter Function


    public int getTotalFoods() {
        return totalFoods;
    }

    public int getId() {
        return id;
    }

    public List<Integer> getFoodPrice() {
        return foodPrice;
    }

    public List<Integer> getFoodID() {
        return foodID;
    }

    public List<String> getFoodName() {
        return foodName;
    }

    //Other Functions


        //function Which Print Data

        public void print(Integer x){
            System.out.print(x);
        }

        public void print(String x){
            System.out.print(x);
        }


        public void print(List<String> x, List<Integer> y){
            for (int i = 0; i < this.totalFoods; i++) {
                System.out.println(x.get(i)+"    "+y.get(i));
            }
        }

        public void print(List<String> x, List<Integer> y, List<Integer> z){
            for (int i = 0; i < this.totalFoods; i++) {
                System.out.println(z.get(i)+"    "+x.get(i)+"    "+y.get(i));
            }
        }

        //functions for adding foods

        public void add(String name, int price){
            foodName.add(name);
            foodPrice.add(price);
            foodID.add(this.id);
            totalFoods++;
            id++;
        }

        public void add(int n){
                for(int i=0; i<n; i++){
                    System.out.print("Enter "+ foodType+"-"+(i+1)+" Name:  ");
                    String name = WRITE.nextLine();
                    System.out.print("Enter "+name+" Price: ");
                    int price = WRITE.nextInt();
                    WRITE.nextLine();
                    add(name, price);
                }
        }

        //Remove Function Which Remove Food

        public void remove(String name){
            if(foodName.contains(name)){
                int indexOfRemoval =  foodName.indexOf(name);
                foodName.remove(indexOfRemoval);
                foodPrice.remove(indexOfRemoval);
                foodID.remove(indexOfRemoval);
                totalFoods--;
            }else{
                System.out.println(foodType+" Name You Entered is Not Present:");
            }
        }

        public void remove(int id){
            if(foodID.contains(id)){
                int indexOfRemoval =  foodID.indexOf(id);
                foodName.remove(indexOfRemoval);
                foodPrice.remove(indexOfRemoval);
                foodID.remove(indexOfRemoval);
                totalFoods--;
            }else{
                System.out.println(foodType+" ID You Entered is Not Present:");
            }
        }

}
