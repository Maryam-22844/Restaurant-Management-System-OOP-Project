package com.LegacyProduction;

public class FastFoods extends Food{

    private String foodType="Fast Food";

    FastFoods(){
        super();
    }

    FastFoods(String foodType){
        super(foodType);
    }

    FastFoods(int id){
        super(id);
    }

    FastFoods(int id, String foodType){
        super(id, foodType);
    }

    FastFoods(int id, int nFood){
        super(id, nFood);
    }

    FastFoods(int id, int nFood, String foodType){
        super(id, nFood, foodType);
    }

}
