package com.LegacyProduction;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import static javax.swing.JOptionPane.WARNING_MESSAGE;


public class GraphicalInterface extends JFrame implements ActionListener {

    String isManager= "";
    private String inputUsername = "";
    private int orderedNumber=0, sum=0;
    JFrame frame;
    JButton signIn, orderPlace, orderCancel, signUp, order, signUpForm, cancelForm, food, myInfo, signOut, back, fastFood, coldDrinks, meal, foodDataButton, proceedButton, addFoodForOrder, khatamShud;
    JTextField userName,nameTF, password, confirmPasswordTF, emailTF, addressTF, phoneNumberTF,inputTakenNumber, nameOfOrder, quantityoFOrder, customerDepositAmount, customerNameTF, customerAddressTF;
    JLabel labelForInfo, name, confirmPassword, email, username, passWord, address, manager, phoneNumber,  messageLabel, name1, price, askNumber, labelForOrder, mealList, fastFoodList, coldDrinksList, nameOrdered, quantityOrdered, priceOrdered, totalBillLabel, totalSumBillLabel, customerNameL, customerAddressL, customerPhoneNumberL ;
    JCheckBox forManager;
    JLabel[] mealFood, fastFoodFood, coldDrinksFood;
    JTextField[] priceFood, nameFood;
    Customer customer=new Customer();
    ArrayList<JLabel> nameListOfOrderedFood= new ArrayList<>(), priceListOfOrderedFood= new ArrayList<>(),quantityListOfOrderedFood= new ArrayList<>();

    GraphicalInterface() {

        //JButton
        customerAddressL= new JLabel();
        customerNameL= new JLabel();
        customerPhoneNumberL= new JLabel();
        customerAddressTF= new JTextField();
        customerNameTF= new JTextField();
        customerDepositAmount= new JTextField();
        khatamShud= new JButton();


        orderPlace= new JButton();
        orderCancel= new JButton();
        nameOrdered= new JLabel();
        quantityOrdered= new JLabel();
        priceOrdered= new JLabel();
        quantityoFOrder= new JTextField();
        nameOfOrder = new JTextField();
        labelForOrder = new JLabel();
        addFoodForOrder= new JButton();
        name1= new JLabel();
        askNumber= new JLabel();
        price = new JLabel();
        inputTakenNumber = new JTextField();
        proceedButton = new JButton();
        foodDataButton = new JButton();
        priceFood= null;
        nameFood= null;

        fastFood = new JButton();
        coldDrinks = new JButton();
        meal = new JButton();
        back = new JButton();
        messageLabel = new JLabel();
        signIn = new JButton();
        signUp = new JButton();
        signUpForm = new JButton();
        cancelForm = new JButton();
        food = new JButton();
        myInfo = new JButton();
        signOut =  new JButton();

        //JTextField
        nameTF= new JTextField();
        confirmPasswordTF= new JTextField();
        emailTF = new JTextField();
        addressTF= new JTextField();
        phoneNumberTF= new JTextField();
        userName = new JTextField();
        password = new JTextField();

        //JLabel
        labelForInfo = new JLabel();
        phoneNumber=new JLabel();
        name=new JLabel();
        confirmPassword=new JLabel();
        email=new JLabel();
        username=new JLabel();
        passWord=new JLabel();
        address=new JLabel();
        manager= new JLabel();

        //JFrame
        frame = new JFrame("First GUI Product");

        //JCheckBox
        forManager = new JCheckBox();


    }

    public void homePage() {

        signIn = new JButton("Sign In");
        signUp = new JButton("Sign Up");
        userName = new JTextField("Username");
        password = new JTextField("Password");
        labelForInfo = new JLabel();


        labelForInfo.setHorizontalTextPosition((int)CENTER_ALIGNMENT);
        labelForInfo.setBounds(150, 100, 300, 40);
        signIn.setBounds(265, 360, 90, 40);
        signUp.setBounds(145, 360, 90, 40);
        userName.setBounds(100, 210, 300, 40);
        password.setBounds(100, 280, 300, 40);
        userName.setBorder(null);
        password.setBorder(null);
        userName.setForeground(Color.GRAY);
        password.setForeground(Color.GRAY);

        add(labelForInfo);
        add(userName);
        add(password);
        add(signUp);
        add(signIn);
        setLayout(null);
        setResizable(false);
        setSize(500, 600);
        setVisible(true);

        //ActionListeners
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        signIn.addActionListener(this);
        signUp.addActionListener(this);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==signIn){
            signInFucntion();
        }else if(e.getSource()==signUp){
            signUpFunction();
        }

    }

    public void signInFucntion(){
        String userNameText = userName.getText().toLowerCase();
        String passwordText = password.getText();

        labelForInfo.setVisible(true);

        if(userNameText.equalsIgnoreCase("Username") || passwordText.equalsIgnoreCase("Password") || userNameText.isBlank() && passwordText.isBlank()){
            labelForInfo.setForeground(Color.RED);
            labelForInfo.setText("PLease Enter Username or Password:");
        }else{
            InputOutputFiles authenticater = new InputOutputFiles();
            boolean auhtentication = authenticater.search(new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\logInInfo.csv"), userNameText, passwordText);
            String[] data= authenticater.findReturn(new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\logInInfo.csv"), userNameText);
            if (auhtentication) {

                labelForInfo.setForeground(Color.GREEN);
                inputUsername = userName.getText();
                inputUsername =userNameText;
                homepageNotVisible(false);
                managerInterface((isManager = data[2]).equalsIgnoreCase("true"));
                System.out.println(isManager+"    "+data[2]);
                alert("Hi! "+((data[2].equalsIgnoreCase("True"))?" Manager..." :" Servant...")+"\nWelcome Frida Restaurant!");

            } else {
                labelForInfo.setForeground(Color.RED);
                labelForInfo.setText("InCorrect Password or Username");
                alert("Wrong Password or Username");
                userName.setText("Username");
                password.setText("Password");
            }
        }

    }

    public void signUpFunction(){
        homepageNotVisible(false);
        signUpForm = new JButton("Sign Up");
        cancelForm = new JButton("Back");
        forManager = new JCheckBox();
        nameTF= new JTextField();
        confirmPasswordTF= new JTextField();
        emailTF = new JTextField();
        addressTF= new JTextField();
        phoneNumberTF= new JTextField();

        userName = new JTextField();
        password = new JTextField();
        labelForInfo = new JLabel();
        phoneNumber=new JLabel();
        name=new JLabel();
        confirmPassword=new JLabel();
        email=new JLabel();
        username=new JLabel();
        passWord=new JLabel();
        address=new JLabel();
        manager= new JLabel();
        password = new JTextField();
        userName = new JTextField();

        //label added into GUI
        add(labelForInfo);
        add(username);
        add(passWord);
        add(confirmPassword);
        add(name);
        add(phoneNumber);
        add(address);
        add(manager);
        add(email);
        add(cancelForm);

        //TextField added into GUI
        add(userName);
        add(password);
        add(confirmPasswordTF);
        add(nameTF);
        add(phoneNumberTF);
        add(addressTF);
        add(forManager);
        add(emailTF);

        //button
        add(signUpForm);


        setSize(500,600);
        labelForInfo.setVisible(true);
        name.setVisible(true);
        nameTF.setVisible(true);
        confirmPassword.setVisible(true);
        confirmPasswordTF.setVisible(true);
        email.setVisible(true);
        emailTF.setVisible(true);
        username.setVisible(true);
        userName.setVisible(true);
        passWord.setVisible(true);
        password.setVisible(true);
        address.setVisible(true);
        addressTF.setVisible(true);
        manager.setVisible(true);
        phoneNumber.setVisible(true);
        phoneNumberTF.setVisible(true);

        //button Interface
        signUpForm.setVisible(true);
        cancelForm.setVisible(true);


        //label Position
        int x=50, w=100,h=40;
        labelForInfo.setBounds(x+100, 10, w+100, h);
        labelForInfo.setVerticalTextPosition((int)(CENTER_ALIGNMENT));
        name.setBounds(x, 60, w, h);
        username.setBounds(x, 110, w, h);
        phoneNumber.setBounds(x, 170, w, h);
        passWord.setBounds(x, 220, w, h);
        confirmPassword.setBounds(x, 270, w, h);
        address.setBounds(x, 320, w, h);
        manager.setBounds(x, 370, w, h);
        email.setBounds(x, 420, w, h);


        //TextField Position
        nameTF.setBounds(x+150, 60, w+100, h);
        userName.setBounds(x+150, 110, w+100, h);
        phoneNumberTF.setBounds(x+150, 170, w+100, h);
        password.setBounds(x+150, 220, w+100, h);
        confirmPasswordTF.setBounds(x+150, 270, w+100, h);
        addressTF.setBounds(x+150, 320, w+100, h);
        forManager.setBounds(x+150, 370, w, h);
        emailTF.setBounds(x+150, 420, w+100, h);
        signUpForm.setBounds(295, 470,100,50);
        cancelForm.setBounds(50,470,100,50);

        //label Text
        labelForInfo.setText("Enter Your Data:");
        name.setText("Name:");
        confirmPassword.setText("Confirm:");
        email.setText("Email:");
        username.setText("Username:");
        passWord.setText("Password:");
        address.setText("Address:");
        manager.setText("Manager:");
        phoneNumber.setText("Phone:");


        cancelForm.addActionListener(e -> {
            sigUpFormNotVisible(false);
            homePage();

        });


        signUpForm.addActionListener(e -> {

            if( userName.getText().isBlank() || nameTF.getText().isBlank() || phoneNumberTF.getText().isBlank() || emailTF.getText().isBlank() || addressTF.getText().isBlank()){
                labelForInfo.setForeground(Color.RED);
                labelForInfo.setText("Please Enter Complete Data Don't left Any Filed");
            }else if( dataAlreadyException(new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\logInInfo.csv"),userName.getText(),"Choose Another Username:")   && regexIllegalMatchException("[0-9a-zA-Z]{4,}",userName.getText(),"Please Enter Right Username") && regexIllegalMatchException("[[0-9]{1,}[a-z]{1,}[A-Z]{1,}]{8,}",password.getText(),"At Least One small, One large and number length greater than 8") && matchingException(password.getText(),confirmPasswordTF.getText(), "Passwords are not Match:") && regexIllegalMatchException("[a-zA-z]+[0-9]+@gmail.com",emailTF.getText().toLowerCase(),"Only Gmail ID's Accpetable")){


                    String line= "";
                    line+=userName.getText().toLowerCase();
                    line+=",";
                    line+=nameTF.getText().toLowerCase();
                    line+=",";
                    line+=phoneNumberTF.getText();
                    line+=",";
                    line+=emailTF.getText().toLowerCase();
                    line+=",";
                    line+=addressTF.getText().toLowerCase();
                    line+=",";

                    String forLoginInfo="";
                    forLoginInfo+=userName.getText().toLowerCase();
                    forLoginInfo+=",";
                    forLoginInfo+=password.getText();

                    File file = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\logInInfo.csv");
                    File file1 = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\CashierInfo.csv");
                    File file2 = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\ManagerInfo.csv");
                    if(file.isFile()){
                        InputOutputFiles forwriting = new InputOutputFiles();
                        if(forManager.isSelected()){
                            forwriting.write(file2,line);
                            forLoginInfo+=",TRUE";
                        }else{
                            forwriting.write(file1,line);
                            forLoginInfo+=",FALSE";
                        }
                        forwriting.write(file, forLoginInfo);

                        sigUpFormNotVisible(false);
                        homePage();
                    }else{
                        System.out.println("Wrong File Name:");
                    }
            }

        });

    }


    //setnotVisible

    public void homepageNotVisible(Boolean b){
        labelForInfo.setVisible(b);
        signIn.setVisible(b);
        signUp.setVisible(b);
        userName.setVisible(b);
        password.setVisible(b);
    }


    public void sigUpFormNotVisible(Boolean b){
        labelForInfo.setVisible(b);
        name.setVisible(b);
        nameTF.setVisible(b);
        confirmPassword.setVisible(b);
        confirmPasswordTF.setVisible(b);
        email.setVisible(b);
        emailTF.setVisible(b);
        username.setVisible(b);
        userName.setVisible(b);
        passWord.setVisible(b);
        password.setVisible(b);
        address.setVisible(b);
        addressTF.setVisible(b);
        manager.setVisible(b);
        phoneNumber.setVisible(b);
        phoneNumberTF.setVisible(b);

        //button Interface
        signUpForm.setVisible(b);
        cancelForm.setVisible(b);

        //checkBox
        forManager.setVisible(b);
    }

    //Cashier Interface


    public void managerInterface(boolean b){
        setMinimumSize(new Dimension(500,600));
        setVisible(true);
        setLayout(null);
        order= new JButton("Order");
        signOut= new JButton("Sign Out");
        food = new JButton("Food");
        myInfo = new JButton("My Info");

        add(order);
        add(signOut);
        add(food);
        add(myInfo);

        order.setVisible(true);
        signOut.setVisible(true);
        food.setVisible(b);
        myInfo.setVisible(true);

        setSize(500,600);
        order.setBounds( b?280:130, 100,(b)?100:250,100);
        signOut.setBounds( 280, 300,100,100);
        food.setBounds( 130, 100,100,100);
        myInfo.setBounds( 130, 300,100,100);


        myInfo.addActionListener(e -> {
            managerInterfaceNotVisible(false);
            myInfoPage();
        });


        signOut.addActionListener(e -> {
            managerInterfaceNotVisible(false);
            homePage();
        });

        food.addActionListener(e -> {
            managerInterfaceNotVisible(false);
            foodInterface();
        });

        order.addActionListener(e -> {
            managerInterfaceNotVisible(false);
            orderInterface();
        });
    }

    /*
    *
    *
    *
    *           Order Interface
    *
    *
    */
    public void orderInterface(){
        setMinimumSize(new Dimension(1400,700));
        setVisible(true);
        setLayout(null);

        orderPlace= new JButton("Order Placed:");
        orderCancel= new JButton("Order Cancel:");
        //labelForOrder= new JLabel("Enter Food: ");
        nameOfOrder= new JTextField("Name");
        quantityoFOrder= new JTextField("Quantity");
        addFoodForOrder= new JButton("Add");
        back= new JButton("Back");
        mealList= new JLabel("Meal List: ");
        fastFoodList= new JLabel("Fast Food List: ");
        coldDrinksList= new JLabel("Cold Drink List: ");
        nameOrdered= new JLabel("Name: ");
        quantityOrdered= new JLabel("Quantity: ");
        priceOrdered= new JLabel("Price: ");




        //labelForOrder.setBounds(750, 30, 100,30);
        nameOrdered.setBounds(750, 80, 100, 50);
        nameOfOrder.setBounds(850, 30, 100,30);
        quantityOrdered.setBounds(950, 80, 100, 50);
        quantityoFOrder.setBounds(1000, 30, 100,30);
        priceOrdered.setBounds(1150, 80, 100, 50);
        addFoodForOrder.setBounds(1200, 30, 100,30);
        back.setBounds(1200,600, 100, 30);
        orderPlace.setBounds(950,600, 150, 30);
        orderCancel.setBounds(750, 600, 150, 30);

        labelForOrder= jLabelWithProperties(new JLabel(),true,750, 30, 100,30,"Enter Food: " );
        totalBillLabel= jLabelWithProperties(new JLabel(), true, 950, 530, 100, 30, "Bill: ");
        totalSumBillLabel= jLabelWithProperties(new JLabel(), true, 1150, 530, 100, 30, String.valueOf(sum));

        add(totalBillLabel);
        add(totalSumBillLabel);
        add(labelForOrder);
        add(nameOfOrder);
        add(quantityoFOrder);
        add(addFoodForOrder);
        add(back);
        add(mealList);
        add(fastFoodList);
        add(coldDrinksList);
        add(nameOrdered);
        add(quantityOrdered);
        add(priceOrdered);
        add(orderCancel);
        add(orderPlace);

        for (JLabel jLabel : nameListOfOrderedFood) {
            add(jLabel);
        }
        for (JLabel jLabel : priceListOfOrderedFood) {
            add(jLabel);
        }
        for (JLabel jLabel : quantityListOfOrderedFood) {
            add(jLabel);
        }


        InputOutputFiles forOrder = new InputOutputFiles();
        File filemeal = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\Meal.csv");
        File fileFastFood = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\FastFood.csv");
        File fileColdDrinks = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\ColdDrinks.csv");

        System.out.println("Lines: "+forOrder.countLines(filemeal));
        System.out.println("Lines: "+forOrder.countLines(fileFastFood));
        System.out.println("Lines: "+forOrder.countLines(fileColdDrinks));
        System.out.println(orderedNumber);

        int totalMeal = forOrder.countLines(filemeal);
        int totalFastFood = forOrder.countLines(fileFastFood);
        int totalColdDrinks = forOrder.countLines(fileColdDrinks);

        int spaceManagement = -1;





        mealList.setBounds(50, 30, 600, 50);
        if(totalMeal>0) {
            mealFood= new JLabel[totalMeal];
            for (int i = 0; i < totalMeal; i++) {
                //System.out.println("Cold Drink level: "+ spaceManagement);
                InputOutputFiles object= new InputOutputFiles();
                String[] data = object.findReturn(filemeal, ',',i);
                mealFood[i] = new JLabel(data[1]+"                         ,                           "+data[2]);
                mealFood[i].setBounds(70, 80 + (50 * (++spaceManagement)), 400, 50);
                add(mealFood[i]);
            }
        }else{
            System.out.println("Cold Drink level: "+ spaceManagement);
            mealFood= new JLabel[1];
            mealFood[0]= new JLabel("Nothing Present in Cold Drink Stock: ");
            mealFood[0].setBounds(70, 80 , 400, 50);
            spaceManagement++;
            add(mealFood[0]);
        }

        fastFoodList.setBounds(50, 80 + (50 * (++spaceManagement)), 400, 50);
        if(totalFastFood>0) {
            fastFoodFood= new JLabel[totalFastFood];
            for (int i = 0; i < totalFastFood; i++) {
                InputOutputFiles object= new InputOutputFiles();
                String[] data = object.findReturn(fileFastFood, ',',i);
                fastFoodFood[i] = new JLabel(data[1]+"                         ,                           "+data[2]);
                fastFoodFood[i].setBounds(70, 80 + (50 * (++spaceManagement)), 400, 50);
                add(fastFoodFood[i]);
            }
        }else{
            System.out.println("Cold Drink level: "+ spaceManagement);
            fastFoodFood= new JLabel[1];
            fastFoodFood[0]= new JLabel("Nothing Present in Fast Food Stock: ");
            fastFoodFood[0].setBounds(70, 80 + (50 * (++spaceManagement)), 400, 50);
            add(fastFoodFood[0]);
        }


        coldDrinksList.setBounds(50, 80 + (50 * (++spaceManagement)), 400, 50);
        if(totalColdDrinks>0) {
            coldDrinksFood= new JLabel[totalColdDrinks];
            for (int i = 0; i < totalColdDrinks; i++) {
                InputOutputFiles object= new InputOutputFiles();
                String[] data = object.findReturn(fileColdDrinks, ',',i);
                coldDrinksFood[i] = new JLabel(data[1]+"                         ,                           "+data[2]);
                coldDrinksFood[i].setBounds(70, 80 + (50 * (++spaceManagement)), 400, 50);
                add(coldDrinksFood[i]);
            }
        }else{
            System.out.println("Cold Drink level: "+ spaceManagement);
            coldDrinksFood= new JLabel[1];
            coldDrinksFood[0]= new JLabel("Nothing Present in Fast Food Stock: ");
            coldDrinksFood[0].setBounds(70, 80 + (50 * (++spaceManagement)), 400, 50);
            add(coldDrinksFood[0]);
        }


        back.addActionListener(e -> {

            for (JLabel jLabel : mealFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : fastFoodFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : coldDrinksFood) {
                jLabel.setVisible(false);
            }
            orderInterfaceNotIndivisible(false);
            managerInterface(isManager.equalsIgnoreCase("true"));
        });

        addFoodForOrder.addActionListener(e -> {
            if(numberFormatExceptionCatcher(quantityoFOrder.getText().trim())) {
                boolean find = false;
                for (int i = 0; i < totalMeal; i++) {
                    if ((mealFood[i].getText().toLowerCase()).contains(nameOfOrder.getText().toLowerCase())) {
                        System.out.println("I m here: With In Meal:");
                        String[] data = mealFood[i].getText().split(",");
                        nameListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 750, 100 + (20 * (++orderedNumber)), 100, 50, data[0].trim()));
                        priceListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 1150, 100 + (20 * (orderedNumber)), 100, 50, data[1].trim()));
                        quantityListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 950, 100 + (20 * (orderedNumber)), 100, 50, quantityoFOrder.getText()));
                        find = true;
                        break;
                    }
                }
                //System.out.println("Before Cold Drinks: ");
                for (int i = 0; i < totalColdDrinks && !find; i++) {
                    if ((coldDrinksFood[i].getText().toLowerCase()).contains(nameOfOrder.getText().toLowerCase())) {
                        System.out.println("I m here: With In Cold Drinks:");
                        String[] data = coldDrinksFood[i].getText().split(",");
                        nameListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 750, 100 + (20 * (++orderedNumber)), 100, 50, data[0].trim()));
                        priceListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 1150, 100 + (20 * (orderedNumber)), 100, 50, data[1].trim()));
                        quantityListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 950, 100 + (20 * (orderedNumber)), 100, 50, quantityoFOrder.getText()));
                        find = true;
                        break;
                    }
                }
                for (int i = 0; i < totalFastFood && !find; i++) {
                    if ((fastFoodFood[i].getText().toLowerCase()).contains(nameOfOrder.getText().toLowerCase())) {
                        System.out.println("I m here: With In Fast Food:");
                        String[] data = fastFoodFood[i].getText().split(",");
                        nameListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 750, 100 + (20 * (++orderedNumber)), 100, 50, data[0].trim()));
                        priceListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 1150, 100 + (20 * (orderedNumber)), 100, 50, data[1].trim()));
                        quantityListOfOrderedFood.add(jLabelWithProperties(new JLabel(), true, 950, 100 + (20 * (orderedNumber)), 100, 50, quantityoFOrder.getText()));
                        find = true;
                        break;
                    }
                }
                if (find) {

                    for (JLabel jLabel : mealFood) {
                        jLabel.setVisible(false);
                    }
                    for (JLabel jLabel : fastFoodFood) {
                        jLabel.setVisible(false);
                    }
                    for (JLabel jLabel : coldDrinksFood) {
                        jLabel.setVisible(false);
                    }

                    sum = 0;


                    for (int l = 0; l < priceListOfOrderedFood.toArray().length; l++) {
                        sum += Integer.parseInt(priceListOfOrderedFood.get(l).getText()) * Integer.parseInt(quantityListOfOrderedFood.get(l).getText().trim());
                    }


                    orderInterfaceNotIndivisible(false);

                    orderInterface();
                } else {
                    alert("Please Enter correct Name:");
                }
            }else{
                alert("Please Enter only Number in Quantity: ");
            }

        });

        orderCancel.addActionListener(e -> {

            for (JLabel jLabel : mealFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : fastFoodFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : coldDrinksFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : nameListOfOrderedFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : priceListOfOrderedFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : quantityListOfOrderedFood) {
                jLabel.setVisible(false);
            }

            nameListOfOrderedFood= new ArrayList<>();
            quantityListOfOrderedFood= new ArrayList<>();
            priceListOfOrderedFood= new ArrayList<>();
            sum=0;
            orderedNumber=0;
            orderInterfaceNotIndivisible(false);
            orderInterface();
        });


        orderPlace.addActionListener(e -> {
            customer.setTotalBill(sum);
            customerInfoBox();
            for (JLabel jLabel : nameListOfOrderedFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : priceListOfOrderedFood) {
                jLabel.setVisible(false);
            }
            for (JLabel jLabel : quantityListOfOrderedFood) {
                jLabel.setVisible(false);
            }

        });

    }

    public void orderInterfaceNotIndivisible(Boolean b){
        labelForInfo.setVisible(b);
        nameOfOrder.setVisible(b);
        addFoodForOrder.setVisible(b);
        back.setVisible(b);
        fastFoodList.setVisible(b);
        mealList.setVisible(b);
        coldDrinksList.setVisible(b);
        quantityoFOrder.setVisible(b);
        orderPlace.setVisible(b);
        orderCancel.setVisible(b);
        nameOrdered.setVisible(b);
        priceOrdered.setVisible(b);
        quantityOrdered.setVisible(b);
        totalBillLabel.setVisible(b);
        totalSumBillLabel.setVisible(b);


    }

    public void managerInterfaceNotVisible(Boolean b){
        food.setVisible(b);
        order.setVisible(b);
        signOut.setVisible(b);
        myInfo.setVisible(b);
    }



    public void myInfoPage(){
        homepageNotVisible(false);
        back = new JButton("Back");

        //JTextField
        nameTF= new JTextField();
        emailTF = new JTextField();
        addressTF= new JTextField();
        phoneNumberTF= new JTextField();
        userName = new JTextField();


        //JTextField Adding Info


        //Jlabel
        labelForInfo = new JLabel();
        phoneNumber=new JLabel();
        name=new JLabel();
        email=new JLabel();
        username=new JLabel();
        address=new JLabel();
        messageLabel = new JLabel();


        //label added into GUI
        add(labelForInfo);
        add(username);
        add(name);
        add(phoneNumber);
        add(address);
        add(email);
        add(messageLabel);

        //TextField added into GUI
        add(userName);
        add(nameTF);
        add(phoneNumberTF);
        add(addressTF);
        add(emailTF);

        userName.setEditable(false);
        nameTF.setEditable(false);
        phoneNumberTF.setEditable(false);
        addressTF.setEditable(false);
        emailTF.setEditable(false);

        userName.setForeground(Color.RED);
        nameTF.setForeground(Color.RED);
        phoneNumberTF.setForeground(Color.RED);
        addressTF.setForeground(Color.RED);
        emailTF.setForeground(Color.RED);


        //button
        add(back);


        //Visibility
        setSize(500,450);
        labelForInfo.setVisible(true);
        name.setVisible(true);
        nameTF.setVisible(true);
        email.setVisible(true);
        emailTF.setVisible(true);
        username.setVisible(true);
        userName.setVisible(true);
        address.setVisible(true);
        addressTF.setVisible(true);
        phoneNumber.setVisible(true);
        phoneNumberTF.setVisible(true);
        messageLabel.setVisible(true);


        //button Interface
        back.setVisible(true);


        //label Position
        int x=50, w=100,h=40;
        messageLabel.setBounds(10, 0, 200,30);
        messageLabel.setVerticalTextPosition((int)(CENTER_ALIGNMENT));
        labelForInfo.setBounds(x+100, 10, w+100, h);
        labelForInfo.setVerticalTextPosition((int)(CENTER_ALIGNMENT));
        name.setBounds(x, 60, w, h);
        username.setBounds(x, 110, w, h);
        phoneNumber.setBounds(x, 170, w, h);
        address.setBounds(x, 220, w, h);
        email.setBounds(x, 270, w, h);


        //TextField Position
        nameTF.setBounds(x+150, 60, w+100, h);
        userName.setBounds(x+150, 110, w+100, h);
        phoneNumberTF.setBounds(x+150, 170, w+100, h);
        addressTF.setBounds(x+150, 220, w+100, h);
        emailTF.setBounds(x+150, 270, w+100, h);
        back.setBounds(295, 320,100,50);


        //label Text
        labelForInfo.setText("About Your Data:");
        name.setText("Name:");
        email.setText("Email:");
        username.setText("Username:");
        address.setText("Address:");
        phoneNumber.setText("Phone:");

        File file = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\logInInfo.csv");

        InputOutputFiles objectForGettingData = new InputOutputFiles();
      String[] data = objectForGettingData.findReturn(file, inputUsername);
        if(data[2].equalsIgnoreCase("True")){
            System.out.println("Enter");
            File file1 = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\ManagerInfo.csv");
                try {
                    data = objectForGettingData.findReturn(file1, inputUsername);
                    if(data==null) {
                        throw new NullPointerException("Related Data Not Found");
                    }
                }catch (NullPointerException e){
                    messageLabel.setText(e.getMessage());
                    messageLabel.setForeground(Color.RED);
                }
        }else if (data[2].equalsIgnoreCase("False")){
            File file1 = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\CashierInfo.csv");
            try {
                data = objectForGettingData.findReturn(file1, inputUsername);
                if(data==null) {
                    throw new NullPointerException("Related Data Not Found");
                }
            }catch (NullPointerException e){
                messageLabel.setText(e.getMessage());
                messageLabel.setForeground(Color.RED);
            }
        }

        if(data!=null){userName.setText(data[0]);
            nameTF.setText(data[1]);
            phoneNumberTF.setText(data[2]);
            emailTF.setText(data[3]);
            addressTF.setText(data[4]);
        }
        else{
            alert("Data Already Present");
        }

        back.addActionListener(e -> {
            myInfoPageNotVisible(false);
            sigUpFormNotVisible(false);
            managerInterface(isManager.equalsIgnoreCase("true"));

        });
    }

    public void myInfoPageNotVisible(Boolean b){
        back.setVisible(b);
        messageLabel.setVisible(b);
        sigUpFormNotVisible(b);
    }

    public void foodInterface(){
        //labelSet on Buttons
        setMinimumSize(new Dimension(500,600));
        fastFood = new JButton("Fast Food");
        meal = new JButton("Meal");
        coldDrinks = new JButton("Cold Drinks");
        back = new JButton("Back");

        //adding component on Window
        add(fastFood);
        add(meal);
        add(coldDrinks);
        add(back);

        //visibillity
        foodInterfaceNotVisible(true);

        //position setting
        int w = 200, h= 70;
        setSize(500,600);
        meal.setBounds(150, 50, w,h);
        fastFood.setBounds(150,160,w,h);
        coldDrinks.setBounds(150, 270, w,h);
        back.setBounds(150, 380,w,h);

        back.addActionListener(e -> {
            foodInterfaceNotVisible(false);
            managerInterface(isManager.equalsIgnoreCase("true"));
        });

        meal.addActionListener(e -> {
            foodInterfaceNotVisible(false);
            commonFoodInterface("Meal.csv");
        });

        fastFood.addActionListener(e -> {
            foodInterfaceNotVisible(false);
            commonFoodInterface("FastFood.csv");
        });

        coldDrinks.addActionListener(e -> {
            foodInterfaceNotVisible(false);
            commonFoodInterface("ColdDrinks.csv");
        });

    }

    public void foodInterfaceNotVisible(Boolean b){
        fastFood.setVisible(b);
        meal.setVisible(b);
        coldDrinks.setVisible(b);
        back.setVisible(b);
    }


    public void commonFoodInterface(String x) {
        try {
            File file = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\"+x);
            if (file.exists()) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);
                String line;
                if ((line = bufferedReader.readLine()) == null) {
                    askNumber = new JLabel("Enter Number: ");
                    inputTakenNumber = new JTextField();
                    proceedButton = new JButton("Proceed");
                    back = new JButton("Back");


                    //visibillity
                    askNumber.setVisible(true);
                    inputTakenNumber.setVisible(true);
                    proceedButton.setVisible(true);
                    back.setVisible(true);

                    //adding component
                    add(askNumber);
                    add(inputTakenNumber);
                    add(proceedButton);
                    add(back);

                    //postionSetup
                    setSize(500, 200);
                    askNumber.setBounds(30, 30, 100, 70);
                    inputTakenNumber.setBounds(150, 50, 300, 30);
                    proceedButton.setBounds(200,100,100,30);
                    back.setBounds(30,30,100,30);

                    back.addActionListener(e -> {
                        commonInterfaceNotVisible(false);
                        foodInterface();
                    });


                    proceedButton.addActionListener(e -> {
                        int number= Integer.parseInt(inputTakenNumber.getText());

                        name1= new JLabel("Name");
                        price= new JLabel("Price/Q");
                        name.setVisible(true);
                        price.setVisible(true);
                        add(name1);
                        add(price);
                        name1.setBounds(120,150,100,30);
                        price.setBounds(320,150,100,30);



                        JTextField[] nameFood=new JTextField[number];
                        JTextField[] priceFood= new JTextField[number];
                        int i=0;
                        for(; i<number; i++){
                            nameFood[i]=new JTextField();
                            priceFood[i]=new JTextField();
                            add(nameFood[i]);
                            add(priceFood[i]);
                            nameFood[i].setVisible(true);
                            priceFood[i].setVisible(true);
                            nameFood[i].setBounds(90, 190+(i*40),100,30);
                            priceFood[i].setBounds(290,190+(i*40), 100,30);
                            setSize(500,300+(50*i));
                        }
                        foodDataButton = new JButton("Store Data");
                        foodDataButton.setVisible(true);
                        add(foodDataButton);
                        i-=2;
                        foodDataButton.setBounds(90,300+(50*i)-40,300,30);
                        System.out.println("Yes We Reach");
                        foodDataButton.addActionListener(e1 -> {
                            Food food = new Food();
                            for(int j=0; j<number ; j++){
                                if(nameFood[j].getText().isBlank() || priceFood[j].getText().isBlank()){
                                    alert("Don't Left Any TextField");
                                }else{
                                    try{
                                        food.add(nameFood[j].getText(), Integer.parseInt(priceFood[j].getText().trim()));

                                    }catch (NumberFormatException p){
                                        alert("Please Enter correct Number Format:");
                                    }
                                }
                            }
                            ArrayList<Integer> foodID =(ArrayList) food.getFoodID();
                            ArrayList<String> foodName =(ArrayList) food.getFoodName();
                            ArrayList<Integer> foodPrice =(ArrayList) food.getFoodPrice();
                            for(int j=0; j<number ; j++){
                                String dataHolder = "" + foodID.get(j)+","+foodName.get(j)+","+foodPrice.get(j);
                                InputOutputFiles justObject = new InputOutputFiles();
                                System.out.println("Adding Data: ");
                                justObject.write(file, dataHolder);
                                nameFood[j].setVisible(false);
                                priceFood[j].setVisible(false);
                            }
                            for (String name2: foodName) {
                                System.out.println(name2);
                            }
                            commonInterfaceNotVisible(false);
                            foodInterface();
                        });

                    });



                }else {
                    alert("File is Already Written if You want to rewrite Delet it first and Make File with The Same name:");
                    commonInterfaceNotVisible(false);
                    foodInterface();
                }
            }else {
                file.createNewFile();
                alert("File Not Found");
                commonInterfaceNotVisible(false);
                foodInterface();
            }

        } catch (IOException e){
            alert(e.getMessage());
            commonInterfaceNotVisible(false);
            foodInterface();
        }
    }

    public void commonInterfaceNotVisible(Boolean b){
        name1.setVisible(b);
        price.setVisible(b);
        back.setVisible(b);
        inputTakenNumber.setVisible(b);
        askNumber.setVisible(b);
        proceedButton.setVisible(b);
        foodDataButton.setVisible(false);
        priceFood = new JTextField[0];
        nameFood = new JTextField[0];

    }


    public void alert(String message) {
        JFrame frame2 = new JFrame();
        JOptionPane.showMessageDialog(frame2, message, "Alert!", WARNING_MESSAGE);
    }

    public JLabel jLabelWithProperties(JLabel a, Boolean b, int x, int y, int width, int height, String label){
        a= new JLabel(label);
        a.setVisible(b);
        a.setBounds(x,y,width,height);
        return a;
    }

    public JTextField jTextFieldWithProperties(JTextField a, Boolean b, int x, int y, int width, int height, String label){
        a= new JTextField(label);
        a.setVisible(b);
        a.setBounds(x,y,width,height);
        return a;
    }

    public JButton jButtonWithProperties(JButton a, Boolean b, int x, int y, int width, int height, String label){
        a= new JButton(label);
        a.setVisible(b);
        a.setBounds(x,y,width,height);
        return a;
    }

    public void customerInfoBox(){
            JFrame jFrame= new JFrame("Customer Info");

            jFrame.setSize(500,200);
            jFrame.setVisible(true);
            jFrame.setResizable(false);
            jFrame.setLayout(null);

            customerNameL= jLabelWithProperties(new JLabel(), true, 30, 10, 100,30,"C. Name: ");
            customerAddressL= jLabelWithProperties(new JLabel(), true, 30, 50, 100,30,"C. Address: ");
            customerPhoneNumberL= jLabelWithProperties(new JLabel(), true, 30, 90, 100,30,"C. Amount: ");


            customerNameTF= jTextFieldWithProperties(customerNameTF, true,120,10 ,330,30, "");
            customerAddressTF= jTextFieldWithProperties(customerAddressTF, true,120, 50, 330,30, "");
            customerDepositAmount= jTextFieldWithProperties(customerDepositAmount, true,120, 90, 330,30, "");

            khatamShud= jButtonWithProperties(new JButton(), true, 30,120 ,420,30,"Proceed");

            jFrame.add(customerAddressL);
            jFrame.add(customerPhoneNumberL);
            jFrame.add(customerNameL);
            jFrame.add(khatamShud);
            jFrame.add(customerAddressTF);
            jFrame.add(customerDepositAmount);
            jFrame.add(customerNameTF);


            khatamShud.addActionListener(e -> {
                if(customerNameTF.getText().isBlank() && customerDepositAmount.getText().trim().isBlank() && customerAddressTF.getText().isBlank()){
                    alert("Please Enter Customer Info:");
                }else{
                    System.out.println(regexIllegalMatchException("[0-9]+",customerDepositAmount.getText().trim())+"    "+customerDepositAmount.getText().trim()+"     "+ (customer.solve())+"    "+(customer.getTotalBill())+"     "+customer.getBalance());
                    if(regexIllegalMatchException("[0-9]{1,}",customerDepositAmount.getText().trim())){
                        customer.setBalance(Integer.parseInt(customerDepositAmount.getText().trim()));
                        if(customer.solve()>=0){
                            customer.setName(customerNameTF.getText());
                            customer.setAddress(customerAddressTF.getText());
                            customer.setBalance( Integer.parseInt(customerDepositAmount.getText().trim()));
                            StringBuilder customerbill= new StringBuilder("\n\n\n"+"*".repeat(60));
                            customerbill.append("\nName:             ");
                            customerbill.append(" ".repeat(20));
                            customerbill.append(customer.getName());
                            customerbill.append("\nAddress:          ");
                            customerbill.append(" ".repeat(20));
                            customerbill.append(customerAddressTF.getText());
                            customerbill.append("\nDate:          "+(new SimpleDateFormat("dd-MM-yyyy")).format(new Date())+"           Time:                "+(new SimpleDateFormat("HH:mm")).format(new Date()));
                            customerbill.append("\nBill:             ");
                            customerbill.append(" ".repeat(20));
                            customerbill.append(sum);
                            customerbill.append("\nCustomer Amount:  ");
                            customerbill.append(" ".repeat(20));
                            customerbill.append((customer.getBalance()));
                            customerbill.append("\nAmount Left:      ");
                            customerbill.append(" ".repeat(20));
                            customerbill.append(customer.solve());
                            customerbill.append("\n").append("*".repeat(60));
                            customerbill.append("\nName:").append(" ".repeat(20)).append("Price:").append(" ".repeat(24)).append("Quantity:");
                            for (int i = 0; i < nameListOfOrderedFood.size(); i++) {
                                customerbill.append("\n").append(nameListOfOrderedFood.get(i).getText().trim()).append(" ".repeat(26-nameListOfOrderedFood.get(i).getText().length())).append(priceListOfOrderedFood.get(i).getText().trim()).append(" ".repeat(30-priceListOfOrderedFood.get(i).getText().length())).append(quantityListOfOrderedFood.get(i).getText().trim());
                            }
                            customerbill.append("\n"+"" +"*".repeat(60)+"\n");
                            customerbill.append(" ".repeat(25)+"Thank You:"+" ".repeat(25));
                            customerbill.append("\n"+"" +"*".repeat(60)+"\n\n\n");
                            System.out.println(customerbill);
                            alert(customerbill.toString());

                            customer= new Customer();
                            nameListOfOrderedFood= new ArrayList<>();
                            priceListOfOrderedFood= new ArrayList<>();
                            quantityListOfOrderedFood= new ArrayList<>();
                            for (JLabel jLabel : mealFood) {
                                jLabel.setVisible(false);
                            }
                            for (JLabel jLabel : fastFoodFood) {
                                jLabel.setVisible(false);
                            }
                            for (JLabel jLabel : coldDrinksFood) {
                                jLabel.setVisible(false);
                            }
                            InputOutputFiles inputOutputFiles= new InputOutputFiles();
                            inputOutputFiles.write(new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Resturent Management System #FriDa\\src\\com\\LegacyProduction\\files\\customerBills.txt"), customerbill.toString());
                            orderInterfaceNotIndivisible(false);
                            sum=0;
                            orderedNumber=0;
                            orderInterface();
                            jFrame.dispose();
                        }else{
                            alert("Enter More Amount:");
                        }

                    }else{
                        alert("Enter Correct Amount Only Number Acceptable");
                    }

                }

            });

            jFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                jFrame.dispose();
            }
        });
    }

    public boolean numberFormatExceptionCatcher(String x){
        try{
            int y= Integer.parseInt(x);
            return true;
        }
        catch (NumberFormatException e){
            alert("Please Enter Number At Number Field: ");
            return false;
        }
    }

    public boolean regexIllegalMatchException(String regex,String x, String message){
        try{
            if(Pattern.matches(regex,x)){return  true;}
            else{ throw new IllegalArgumentException(); }
        }
        catch (IllegalArgumentException e){ alert(message); return false; }
    }

    public boolean regexIllegalMatchException(String regex,String x){
        try{
            if(Pattern.matches(regex,x)){return  true;}
            else{ throw new IllegalArgumentException(); }
        }
        catch (IllegalArgumentException e){  return false; }
    }

    public boolean matchingException(String x, String y, String message){
        try{
            if(x.equals(y)){
                return true;
            }else{
                throw new IllegalArgumentException();
            }
        }catch (IllegalArgumentException e){
            alert(message);
            return false;
        }
    }

    public boolean dataAlreadyException(File file, String x, String message){
        try{
            InputOutputFiles y = new InputOutputFiles();
            if(y.search(file, x)){throw new IllegalStateException();}
            else return true;
        }catch (IllegalStateException e){
            alert(message);
            return false;
        }


    }

}

